//! Output format based on the format used by [Fribbels HSR Optimizer],
//! devised by [kel-z's HSR-Scanner].
//!
//! [Fribbels HSR Optimizer]: https://github.com/fribbels/hsr-optimizer
//! [kel-z's HSR-Scanner]: https://github.com/kel-z/HSR-Scanner

mod converters;
mod exporter;
mod handlers;
mod models;
#[cfg(test)]
mod tests;
mod utils;

pub use exporter::OptimizerExporter;
pub use models::*;
